from GUI.othello_gui import OthelloGUI

if __name__ == "__main__":
    othello_gui = OthelloGUI(player_mode="ai")
    othello_gui.run_game()